package de.templum.routeplaner.view.helper;

public interface OnSwipeListener {
    void onRemove(int position);
    int getItemCount();
}
